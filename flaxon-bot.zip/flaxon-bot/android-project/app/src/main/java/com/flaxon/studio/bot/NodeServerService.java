package com.flaxon.studio.bot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

/**
 * NodeServerService
 *
 * Runs the Node.js backend (server.js) as a foreground service.
 * The Node.js runtime and the app bundle must be pre-bundled in assets/.
 *
 * HOW IT WORKS:
 * ─────────────────────────────────────────────────────────────────
 * 1. On first launch, the service extracts the Node.js binary and
 *    the backend bundle from assets/ to the app's private files dir.
 * 2. It launches the Node.js process using Runtime.exec().
 * 3. stdout/stderr are forwarded to Logcat.
 * 4. The service runs in the foreground with a persistent notification
 *    to prevent Android from killing it.
 *
 * BUNDLING NODE.JS FOR ANDROID:
 * ─────────────────────────────────────────────────────────────────
 * Option A — nodejs-mobile-react-native / nodejs-mobile (recommended):
 *   Use the "nodejs-mobile" SDK which bundles a full Node.js runtime
 *   for Android ARM. See: https://github.com/nicktindall/nodejs-mobile
 *
 * Option B — Termux-style approach (for Termux builds):
 *   If running inside Termux, Node.js is already installed and accessible.
 *   The service simply calls "node server.js" directly.
 *
 * This implementation supports BOTH modes based on what's available.
 */
public class NodeServerService extends Service {

    private static final String TAG = "NodeServerService";
    private static final String CHANNEL_ID = "flaxon_bot_service";
    private static final int NOTIFICATION_ID = 1001;

    private Process nodeProcess;
    private Thread outputThread;
    private Thread errorThread;
    private boolean running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, buildNotification());

        if (!running) {
            running = true;
            new Thread(this::startNodeServer).start();
        }

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        running = false;
        stopNodeServer();
    }

    private void startNodeServer() {
        try {
            // Extract backend files from assets to private storage
            File backendDir = extractBackend();
            if (backendDir == null) {
                Log.e(TAG, "Failed to extract backend files");
                return;
            }

            // Find Node.js executable
            String nodePath = findNodeExecutable(backendDir);
            if (nodePath == null) {
                Log.e(TAG, "Node.js not found. Please install Node.js or bundle it with the app.");
                return;
            }

            File serverFile = new File(backendDir, "backend/server.js");
            if (!serverFile.exists()) {
                Log.e(TAG, "server.js not found at: " + serverFile.getAbsolutePath());
                return;
            }

            String[] cmd = { nodePath, serverFile.getAbsolutePath() };
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.directory(new File(backendDir, "backend"));
            pb.environment().put("PORT", "3000");
            pb.environment().put("NODE_ENV", "production");
            pb.environment().put("HOME", getFilesDir().getAbsolutePath());
            pb.redirectErrorStream(false);

            Log.i(TAG, "Starting Node.js: " + nodePath + " " + serverFile.getAbsolutePath());
            nodeProcess = pb.start();

            // Stream stdout to Logcat
            outputThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(nodeProcess.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        Log.i(TAG, "[Node stdout] " + line);
                    }
                } catch (IOException e) {
                    Log.e(TAG, "stdout read error", e);
                }
            });

            // Stream stderr to Logcat
            errorThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(nodeProcess.getErrorStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        Log.w(TAG, "[Node stderr] " + line);
                    }
                } catch (IOException e) {
                    Log.e(TAG, "stderr read error", e);
                }
            });

            outputThread.start();
            errorThread.start();

            int exitCode = nodeProcess.waitFor();
            Log.w(TAG, "Node.js exited with code: " + exitCode);

            // Restart on unexpected exit
            if (running) {
                Thread.sleep(2000);
                startNodeServer();
            }

        } catch (Exception e) {
            Log.e(TAG, "Error starting Node.js server", e);
        }
    }

    /**
     * Extracts backend files from assets to the app's private directory.
     * Returns the root directory containing backend/ and node_modules/.
     */
    private File extractBackend() {
        File filesDir = getFilesDir();
        File appDir = new File(filesDir, "flaxon_app");
        File versionFile = new File(appDir, ".version");

        // Check if already extracted with same version
        try {
            if (versionFile.exists()) {
                Log.d(TAG, "Backend already extracted");
                return appDir;
            }
        } catch (Exception e) {
            // Re-extract
        }

        try {
            // Create directory
            if (!appDir.exists()) appDir.mkdirs();

            // Copy backend files from assets
            copyAssetDir("app_bundle", appDir);

            // Write version file
            try (FileOutputStream fos = new FileOutputStream(versionFile)) {
                fos.write("1.0.0".getBytes());
            }

            Log.i(TAG, "Backend extracted to: " + appDir.getAbsolutePath());
            return appDir;
        } catch (Exception e) {
            Log.e(TAG, "Failed to extract backend", e);
            return null;
        }
    }

    private void copyAssetDir(String assetPath, File targetDir) throws IOException {
        String[] assets = getAssets().list(assetPath);
        if (assets == null || assets.length == 0) {
            // It's a file, copy it
            File target = new File(targetDir.getParent(), targetDir.getName());
            copyAssetFile(assetPath, target);
            return;
        }
        if (!targetDir.exists()) targetDir.mkdirs();
        for (String asset : assets) {
            String childAsset = assetPath + "/" + asset;
            File childTarget = new File(targetDir, asset);
            String[] subAssets = getAssets().list(childAsset);
            if (subAssets != null && subAssets.length > 0) {
                copyAssetDir(childAsset, childTarget);
            } else {
                copyAssetFile(childAsset, childTarget);
            }
        }
    }

    private void copyAssetFile(String assetPath, File target) throws IOException {
        try (InputStream is = getAssets().open(assetPath);
             OutputStream os = new FileOutputStream(target)) {
            byte[] buf = new byte[8192];
            int len;
            while ((len = is.read(buf)) > 0) os.write(buf, 0, len);
        }
    }

    /**
     * Finds the Node.js executable.
     * Priority: 1. Bundled node binary, 2. Termux node, 3. System PATH
     */
    private String findNodeExecutable(File appDir) {
        // 1. Bundled node binary in the extracted app dir
        File bundledNode = new File(appDir, "bin/node");
        if (bundledNode.exists() && bundledNode.canExecute()) {
            return bundledNode.getAbsolutePath();
        }

        // 2. Termux node (common when running in Termux environment)
        String[] termuxPaths = {
            "/data/data/com.termux/files/usr/bin/node",
            "/data/data/com.termux/files/usr/bin/nodejs"
        };
        for (String path : termuxPaths) {
            File f = new File(path);
            if (f.exists() && f.canExecute()) {
                Log.i(TAG, "Using Termux Node.js: " + path);
                return path;
            }
        }

        // 3. System PATH (unlikely on non-rooted Android, but try anyway)
        String[] systemPaths = { "/usr/bin/node", "/usr/local/bin/node", "/bin/node" };
        for (String path : systemPaths) {
            File f = new File(path);
            if (f.exists() && f.canExecute()) return path;
        }

        return null;
    }

    private void stopNodeServer() {
        if (nodeProcess != null) {
            nodeProcess.destroy();
            nodeProcess = null;
        }
        if (outputThread != null) {
            outputThread.interrupt();
            outputThread = null;
        }
        if (errorThread != null) {
            errorThread.interrupt();
            errorThread = null;
        }
        Log.i(TAG, "Node.js server stopped");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Flaxon Bot Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Keeps the Minecraft bot server running");
            channel.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                ? PendingIntent.FLAG_IMMUTABLE
                : 0
        );

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Flaxon Bot")
            .setContentText("Bot server is running on port 3000")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build();
    }
}
