-keep class com.flaxon.studio.bot.** { *; }
-keepclassmembers class com.flaxon.studio.bot.MainActivity$AndroidBridge {
    public *;
}
-dontwarn okhttp3.**
-dontwarn okio.**
