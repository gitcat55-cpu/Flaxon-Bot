# Web Research Summary — Flaxon Bot

Compiled before implementation. Sources: GitHub, official docs, MDN, Ionic/Capacitor docs.

---

## 1. Mineflayer (PrismarineJS)

- **Supported Minecraft versions:** 1.8 through 1.21.11 (Java Edition only via `mineflayer`)
- **Bot creation:** `mineflayer.createBot({ host, port, username, auth: 'offline' })`
- **Key events:** `spawn`, `chat`, `death`, `kicked`, `end`, `health`, `playerJoined`, `playerLeft`
- **Movement API:** `bot.setControlState('forward'|'back'|'left'|'right'|'jump'|'sneak'|'sprint', true/false)`
- **Chat:** `bot.chat(message)` — sends in-game chat or slash commands
- **Plugin system:** `bot.loadPlugin(fn)` — plugins extend `bot` namespace; standard practice to namespace as `bot.myPlugin`
- **Pathfinder plugin:** `mineflayer-pathfinder` — provides `GoalFollow`, `GoalBlock`, `GoalXZ`, etc. Loaded via `bot.loadPlugin(pathfinder)`
- **Inventory:** `bot.inventory.items()` — returns array of `{name, count, type, slot}`
- **Error handling best practice:** listen to `error`, `kicked`, `end` events separately; wrap `createBot` in try/catch
- **Reconnect pattern:** on `end`/`kicked` events, use `setTimeout` with a delay before calling `createBot` again
- **One bot at a time:** no built-in limit; enforced in application layer by tracking `activeBot` reference

## 2. Node.js Backend Design

- **Express.js** is the standard for REST API servers; lightweight, middleware-based
- **Server-Sent Events (SSE):** `res.setHeader('Content-Type', 'text/event-stream')` — ideal for real-time log and bot event streaming without WebSockets
- **File-based JSON storage:** sufficient for profile persistence in a single-user mobile app (no database overhead)
- **morgan** for HTTP request logging during development
- **cors** middleware required for WebView → localhost API communication when origins differ
- **Process stability:** `process.on('uncaughtException')` and `process.on('unhandledRejection')` prevent crashes

## 3. Android WebView Integration

- **WebView configuration essentials:** `setJavaScriptEnabled(true)`, `setDomStorageEnabled(true)`, `setMixedContentMode(MIXED_CONTENT_ALWAYS_ALLOW)` for HTTP on Android 9+
- **Cleartext traffic:** requires `android:usesCleartextTraffic="true"` in `<application>` AND a `network_security_config.xml` that explicitly permits cleartext for `127.0.0.1`
- **JavaScript bridge:** `webView.addJavascriptInterface(obj, "BridgeName")` + `@JavascriptInterface` annotation; accessible as `window.BridgeName` in JS
- **Blocking navigation:** `WebViewClient.shouldOverrideUrlLoading()` — return `false` to load in WebView, `true` to intercept (open in browser)
- **Debugging:** `WebView.setWebContentsDebuggingEnabled(true)` enables Chrome DevTools remote debugging
- **androidx.webkit:** `WebViewFeature.ALGORITHMIC_DARKENING` for automatic dark mode support
- **API 24+ (Android 7)** is the recommended minimum; covers ~99% of active devices

## 4. Android Foreground Service

- **Required for long-running background work** (Node.js process) to prevent Android from killing it
- **`START_STICKY`** return value from `onStartCommand` tells Android to restart the service if killed
- **Notification channel** required on Android 8+ (API 26+) for foreground services
- **`foregroundServiceType="dataSync"`** required in manifest for Android 14+
- **`startForegroundService()`** must be used on Android 8+ before calling `startForeground()` inside the service

## 5. Node.js on Android

- **nodejs-mobile** (formerly nodejs-mobile-react-native, now maintained by nicktindall): bundles full Node.js runtime for ARM Android inside an APK; uses `libnode.so`
- **Termux approach:** Node.js installed at `/data/data/com.termux/files/usr/bin/node`; fastest way to run Node.js apps on Android without a build pipeline
- **Runtime.exec() / ProcessBuilder:** can launch `node server.js` as a child process if binary path is known; stdout/stderr must be consumed on separate threads to avoid blocking
- **Asset extraction:** bundle `backend/` + `node_modules/` in `assets/`, extract to `getFilesDir()` on first launch

## 6. Capacitor (Alternative to Custom WebView)

- **Capacitor 6** supports Android API 24+, requires Chrome 60+ WebView
- **Local HTTP server:** Capacitor auto-hosts app files at `http://localhost` with a local server
- **`allowNavigation`:** config array of domains/IPs the WebView may load; required for custom server URLs
- **`androidScheme: "https"`** recommended for secure context APIs (geolocation, etc.)
- **Custom plugins:** Java/Kotlin classes annotated with `@CapacitorPlugin` expose native APIs to JavaScript
- **Decision:** For this project, a custom `WebViewActivity` was chosen over Capacitor to reduce dependency overhead and allow full control over the foreground service lifecycle

## 7. Mobile UI Design Patterns (2024–2025)

- **Dark-first design:** default dark theme reduces eye strain; Minecraft aesthetic reinforces brand
- **Pixel/retro styling:** box-shadows used to simulate 3D pressed-button effect (Minecraft UI convention)
- **SSE over WebSocket:** simpler server-side implementation; no library needed; browser-native `EventSource` API
- **Single-screen SPA with tab navigation:** reduces WebView page loads; `display:none` toggling for screen switching
- **Touch targets:** minimum 44×44px for interactive elements (Apple HIG / Material Design guideline)
- **Responsive grid:** CSS Grid with `grid-template-columns: repeat(auto-fit, ...)` for adaptive stat cards
- **D-pad control layout:** flex column/row centering; 52px tap targets on desktop, 46px on small screens

---

*Research performed: April 2026*
