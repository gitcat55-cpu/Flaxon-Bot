# 🤖 Flaxon Bot — Complete Minecraft Bot Controller

**Package:** `com.flaxon.studio.bot`  
**Version:** 1.0.0  
**Stack:** Node.js + Mineflayer · Express · Vanilla JS · Android WebView

---

## 📁 Project Structure

```
flaxon-bot/
├── backend/                    ← Node.js server + Mineflayer bot engine
│   ├── server.js               ← Express API server (port 3000)
│   ├── botManager.js           ← Mineflayer lifecycle, actions, events
│   ├── profileStore.js         ← JSON-file profile persistence
│   ├── package.json
│   └── data/
│       └── profiles.json       ← Auto-created on first run
│
├── frontend/                   ← Web UI (served by backend, loaded in WebView)
│   ├── index.html              ← SPA with 4 screens: Home, Bots, Stats, Logs
│   ├── app.js                  ← All frontend logic (API calls, SSE, UI state)
│   └── style.css               ← Minecraft-themed dark UI (user-provided)
│
├── android-project/            ← Android Studio project
│   ├── app/
│   │   ├── build.gradle
│   │   ├── proguard-rules.pro
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── java/com/flaxon/studio/bot/
│   │       │   ├── MainActivity.java       ← WebView host + JS bridge
│   │       │   └── NodeServerService.java  ← Foreground service for Node.js
│   │       └── res/
│   │           ├── layout/activity_main.xml
│   │           ├── values/strings.xml
│   │           ├── values/themes.xml
│   │           └── xml/network_security_config.xml
│   ├── build.gradle
│   ├── settings.gradle
│   └── gradle.properties
│
├── package.json                ← Root convenience scripts
└── README.md
```

---

## ⚡ Quick Start (Desktop / Termux — No Android Build)

### 1. Install Node.js dependencies

```bash
cd backend
npm install
```

### 2. Start the server

```bash
node server.js
# or:
npm start
```

### 3. Open the UI

Navigate to **http://localhost:3000** in your browser.

The same URL is what the Android WebView loads.

---

## 📱 Running on Android (Termux — Easiest Method)

This is the fastest way to run the app on Android without building an APK.

### Step 1 — Install Termux

Download Termux from [F-Droid](https://f-droid.org/packages/com.termux/) (not Play Store).

### Step 2 — Set up Node.js in Termux

```bash
pkg update && pkg upgrade -y
pkg install nodejs -y
node -v   # should print v18+ or v20+
```

### Step 3 — Copy project to Termux

```bash
# Option A: clone/copy to ~/flaxon-bot
cp -r /sdcard/flaxon-bot ~/flaxon-bot

# Option B: or download directly via git
# git clone <your-repo-url> ~/flaxon-bot
```

### Step 4 — Install dependencies & run

```bash
cd ~/flaxon-bot/backend
npm install
node server.js
```

### Step 5 — Open in any Android browser

Go to: **http://127.0.0.1:3000**

Or use the full Android APK described below to get a dedicated native app.

---

## 🏗️ Building the Android APK

### Prerequisites

| Tool | Version |
|------|---------|
| Android Studio | Hedgehog 2023.1+ |
| JDK | 17+ |
| Android SDK | API 34 |
| Gradle | 8.4 (auto-downloaded) |
| Node.js (for bundling) | 18 LTS or 20 LTS |

### Method A — WebView pointing to running server (simplest)

This method builds an APK that simply loads `http://127.0.0.1:3000`. The Node.js server must be running separately (e.g. via Termux or a cloud server).

1. Open `android-project/` in Android Studio
2. Sync Gradle
3. In `MainActivity.java`, confirm `BACKEND_URL = "http://127.0.0.1:3000"`
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK is at `app/build/outputs/apk/debug/app-debug.apk`

### Method B — Fully self-contained APK with bundled Node.js

Uses [nodejs-mobile](https://github.com/nicktindall/nodejs-mobile) to bundle the Node.js runtime inside the APK.

#### Step 1 — Install nodejs-mobile Gradle plugin

Add to `android-project/app/build.gradle`:

```gradle
plugins {
    id 'com.janeasystems.cdvnodejsmobile' version '0.2.9'
}

nodejs {
    nodeDir = file('src/main/assets/nodejs-project')
}
```

#### Step 2 — Create the nodejs-project assets folder

```bash
mkdir -p android-project/app/src/main/assets/nodejs-project
cp -r backend/* android-project/app/src/main/assets/nodejs-project/
cp -r frontend android-project/app/src/main/assets/nodejs-project/

cd android-project/app/src/main/assets/nodejs-project
npm install --production
```

#### Step 3 — Update NodeServerService.java

Replace `findNodeExecutable()` to use the nodejs-mobile bridge:

```java
// Use nodejs-mobile bridge instead of Runtime.exec()
// See: https://github.com/nicktindall/nodejs-mobile#android-usage
NodeMobile.startWithArguments(new String[]{"node", "server.js"}, ...);
```

#### Step 4 — Build

```bash
cd android-project
./gradlew assembleRelease
```

APK: `app/build/outputs/apk/release/app-release-unsigned.apk`

#### Step 5 — Sign the APK

```bash
# Generate keystore (one time)
keytool -genkeypair -v \
  -keystore flaxon.keystore \
  -alias flaxon \
  -keyalg RSA -keysize 2048 \
  -validity 10000

# Sign
apksigner sign \
  --ks flaxon.keystore \
  --ks-alias flaxon \
  --out flaxon-bot-release.apk \
  app/build/outputs/apk/release/app-release-unsigned.apk
```

---

## 🔌 API Reference

All endpoints are served at `http://127.0.0.1:3000`.

### Profiles

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/profiles` | List all profiles |
| `POST` | `/api/profiles` | Create profile `{name, host, port}` |
| `PUT` | `/api/profiles/:id` | Update profile |
| `DELETE` | `/api/profiles/:id` | Delete profile |

### Bot Control

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/bot/status` | Get bot status, health, position |
| `POST` | `/api/bot/start` | Start bot `{profileId}` |
| `POST` | `/api/bot/stop` | Stop active bot |
| `POST` | `/api/bot/chat` | Send chat `{message}` |
| `POST` | `/api/bot/action` | Execute action `{action, params}` |

### Streaming (Server-Sent Events)

| Path | Description |
|------|-------------|
| `GET /api/logs/stream` | Real-time log stream (SSE) |
| `GET /api/events/stream` | Real-time bot events (SSE) |

### Bot Actions

Send via `POST /api/bot/action` with `{ "action": "<name>" }`:

| Action | Description |
|--------|-------------|
| `move_forward` | Move forward (500ms) |
| `move_back` | Move backward |
| `move_left` | Strafe left |
| `move_right` | Strafe right |
| `jump` | Jump |
| `sneak` | Toggle sneak |
| `sprint` | Toggle sprint |
| `stop_all` | Stop all movement + pathfinder |
| `attack` | Attack nearest entity |
| `follow_nearest_player` | Follow nearest player (pathfinder) |
| `respawn` | Respawn after death |
| `look_north/south/east/west` | Face direction |
| `get_inventory` | Returns inventory items array |
| `get_position` | Returns `{x, y, z}` |
| `get_players` | Returns online player list |

---

## 🔒 Security Notes

- The API listens on `127.0.0.1:3000` (loopback only). It is NOT exposed to the network by default.
- If deploying to a remote server, add authentication middleware to Express.
- Input validation is applied on all profile fields and bot actions.
- Only one bot instance can be active at a time (enforced server-side).
- Profile edits and deletes are blocked while a bot is active.

---

## 🐛 Troubleshooting

| Problem | Fix |
|---------|-----|
| `Cannot find module 'mineflayer'` | Run `npm install` in `backend/` |
| Bot connects then immediately disconnects | Server may be using online-mode. Mineflayer uses offline auth by default. |
| WebView shows blank / error | Make sure `node server.js` is running first |
| Port 3000 in use | Change `PORT` env var: `PORT=4000 node server.js` |
| Android WebView can't reach server | Check `network_security_config.xml` allows `127.0.0.1` cleartext |
| `ERR_CLEARTEXT_NOT_PERMITTED` | `android:usesCleartextTraffic="true"` must be in AndroidManifest.xml |

---

## 📦 Dependencies

### Backend
- `express` — HTTP API server
- `mineflayer` — Minecraft Java bot engine
- `mineflayer-pathfinder` — Pathfinding / following
- `cors` — Cross-origin headers
- `morgan` — HTTP request logging
- `uuid` — Profile ID generation

### Android
- `androidx.webkit` — WebView with modern features
- `androidx.appcompat` — Base Android compat
- `com.google.android.material` — Material UI components

---

## 📜 Research Summary

See `RESEARCH.md` for the full web research notes compiled before implementation.

---

*Flaxon Studio Bot — Built for Minecraft Java Edition automation on Android*
