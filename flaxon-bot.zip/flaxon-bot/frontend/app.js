(() => {
  // ─── Config ───────────────────────────────────────────────────────────────
  const API_BASE = (() => {
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      return `http://${window.location.hostname}:3000`;
    }
    return `http://${window.location.hostname}:3000`;
  })();

  // ─── State ────────────────────────────────────────────────────────────────
  let profiles = [];
  let botStatus = { online: false, profile: null };
  let autoscroll = true;
  let deleteTargetId = null;
  let statsInterval = null;
  let logStream = null;
  let eventStream = null;

  // ─── Init ─────────────────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => {
    fetchProfiles();
    fetchStatus();
    startLogStream();
    startEventStream();
    statsInterval = setInterval(fetchStatus, 3000);

    document.getElementById('chat-input').addEventListener('keydown', e => {
      if (e.key === 'Enter') sendChatFromInput();
    });

    document.querySelectorAll('.modal').forEach(m => {
      m.addEventListener('click', e => { if (e.target === m) m.classList.remove('show'); });
    });
  });

  // ─── API helpers ─────────────────────────────────────────────────────────
  async function api(method, path, body) {
    try {
      const opts = { method, headers: { 'Content-Type': 'application/json' } };
      if (body) opts.body = JSON.stringify(body);
      const res = await fetch(`${API_BASE}${path}`, opts);
      return await res.json();
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  // ─── Screen navigation ────────────────────────────────────────────────────
  window.switchScreen = function(name) {
    document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.getElementById(`screen-${name}`).classList.remove('hidden');
    document.querySelector(`[data-screen="${name}"]`).classList.add('active');

    if (name === 'bots') renderBotList();
    if (name === 'stats') refreshStats();
  };

  // ─── Toast ────────────────────────────────────────────────────────────────
  window.showToast = function(msg, type = '') {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.className = `toast show ${type}`;
    setTimeout(() => el.classList.remove('show'), 3000);
  };

  // ─── Modal ────────────────────────────────────────────────────────────────
  window.closeModal = function(id) {
    document.getElementById(id).classList.remove('show');
  };

  function openModal(id) {
    document.getElementById(id).classList.add('show');
  }

  // ─── Profiles ─────────────────────────────────────────────────────────────
  async function fetchProfiles() {
    const data = await api('GET', '/api/profiles');
    if (data.success) {
      profiles = data.profiles;
      document.getElementById('stat-profiles').textContent = profiles.length;
      renderBotList();
    }
  }

  function renderBotList() {
    const container = document.getElementById('bots-list');
    if (profiles.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🤖</div>
          <div>No profiles yet</div>
          <button class="button primary small" onclick="openAddModal()">Create your first bot</button>
        </div>`;
      return;
    }

    container.innerHTML = '';
    profiles.forEach(p => {
      const isActive = botStatus.profile && botStatus.profile.profileId === p.id;
      const card = document.createElement('div');
      card.className = 'bot-card';
      card.innerHTML = `
        <div class="bot-avatar-small">🤖</div>
        <div class="bot-card-info">
          <div class="bot-card-name">${esc(p.name)}</div>
          <div class="bot-card-server">${esc(p.host)}:${p.port}</div>
          <div class="bot-card-meta">
            <span class="tag java">Java</span>
            <span class="tag ${isActive ? 'online' : 'offline'}">${isActive ? 'Online' : 'Offline'}</span>
          </div>
        </div>
        <div class="bot-card-actions">
          ${isActive
            ? `<button class="button destructive small" onclick="stopBotById('${p.id}')">
                 <span class="material-symbols-outlined">stop</span> Stop
               </button>`
            : `<button class="button primary small" onclick="startBotById('${p.id}')">
                 <span class="material-symbols-outlined">play_arrow</span> Start
               </button>`
          }
          <button class="button secondary small" onclick="openEditModal('${p.id}')">
            <span class="material-symbols-outlined">edit</span>
          </button>
          <button class="button destructive small" onclick="openDeleteModal('${p.id}','${esc(p.name)}')">
            <span class="material-symbols-outlined">delete</span>
          </button>
        </div>`;
      container.appendChild(card);
    });
  }

  window.openAddModal = function() {
    document.getElementById('profile-edit-id').value = '';
    document.getElementById('modal-profile-title').textContent = 'New Bot Profile';
    document.getElementById('input-bot-name').value = '';
    document.getElementById('input-server-host').value = '';
    document.getElementById('input-server-port').value = '25565';
    openModal('modal-profile');
    setTimeout(() => document.getElementById('input-bot-name').focus(), 100);
  };

  window.openEditModal = function(id) {
    const p = profiles.find(x => x.id === id);
    if (!p) return;
    document.getElementById('profile-edit-id').value = p.id;
    document.getElementById('modal-profile-title').textContent = 'Edit Profile';
    document.getElementById('input-bot-name').value = p.name;
    document.getElementById('input-server-host').value = p.host;
    document.getElementById('input-server-port').value = p.port;
    openModal('modal-profile');
  };

  window.saveProfile = async function() {
    const id = document.getElementById('profile-edit-id').value;
    const name = document.getElementById('input-bot-name').value.trim();
    const host = document.getElementById('input-server-host').value.trim();
    const port = document.getElementById('input-server-port').value.trim();

    if (!name) return showToast('Bot name is required', 'error');
    if (!host) return showToast('Server host is required', 'error');
    if (!port || isNaN(port) || +port < 1 || +port > 65535) return showToast('Invalid port number', 'error');

    const body = { name, host, port };
    const data = id
      ? await api('PUT', `/api/profiles/${id}`, body)
      : await api('POST', '/api/profiles', body);

    if (data.success) {
      closeModal('modal-profile');
      showToast(id ? 'Profile updated!' : 'Profile created!', 'success');
      await fetchProfiles();
    } else {
      showToast(data.error || 'Failed to save profile', 'error');
    }
  };

  window.openDeleteModal = function(id, name) {
    deleteTargetId = id;
    document.getElementById('delete-profile-name').textContent = name;
    openModal('modal-delete');
  };

  window.confirmDelete = async function() {
    if (!deleteTargetId) return;
    const data = await api('DELETE', `/api/profiles/${deleteTargetId}`);
    if (data.success) {
      closeModal('modal-delete');
      showToast('Profile deleted', '');
      await fetchProfiles();
    } else {
      showToast(data.error || 'Delete failed', 'error');
    }
    deleteTargetId = null;
  };

  // ─── Bot Control ──────────────────────────────────────────────────────────
  async function fetchStatus() {
    const data = await api('GET', '/api/bot/status');
    if (!data.success) return;

    botStatus = data;

    const dot = document.getElementById('connection-dot');
    if (dot) dot.style.background = data.online ? '#3c8527' : '#c83737';

    document.getElementById('stat-health').textContent = data.health !== null ? data.health : '—';
    document.getElementById('stat-food').textContent = data.food !== null ? data.food : '—';

    const uptime = formatUptime(data.uptime || 0);
    document.getElementById('stat-uptime').textContent = data.online ? uptime : '—';

    const statusLine = document.getElementById('home-status-line');
    if (data.online && data.profile) {
      statusLine.textContent = `${data.profile.name} online → ${data.profile.host}:${data.profile.port}`;
    } else {
      statusLine.textContent = 'No bot running. Select a profile to start.';
    }

    const startBtn = document.getElementById('btn-quick-start');
    const stopBtn = document.getElementById('btn-quick-stop');
    if (startBtn) startBtn.disabled = data.online;
    if (stopBtn) stopBtn.disabled = !data.online;

    renderBotList();
  }

  window.startBotById = async function(profileId) {
    const data = await api('POST', '/api/bot/start', { profileId });
    if (data.success) {
      showToast('Bot is connecting...', 'success');
      setTimeout(fetchStatus, 1500);
    } else {
      showToast(data.error || 'Failed to start bot', 'error');
    }
  };

  window.stopBotById = async function(profileId) {
    const data = await api('POST', '/api/bot/stop');
    if (data.success) {
      showToast('Bot stopped', '');
      setTimeout(fetchStatus, 500);
    } else {
      showToast(data.error || 'Failed to stop bot', 'error');
    }
  };

  window.quickStart = function() {
    if (profiles.length === 0) {
      showToast('Create a profile first', 'error');
      switchScreen('bots');
      return;
    }
    if (profiles.length === 1) {
      startBotById(profiles[0].id);
      return;
    }
    const list = document.getElementById('start-profile-list');
    list.innerHTML = '';
    profiles.forEach(p => {
      const btn = document.createElement('button');
      btn.className = 'button secondary';
      btn.style.width = '100%';
      btn.innerHTML = `🤖 ${esc(p.name)} <span style="font-size:12px;color:#aaa;margin-left:8px;">${esc(p.host)}:${p.port}</span>`;
      btn.onclick = () => { closeModal('modal-start'); startBotById(p.id); };
      list.appendChild(btn);
    });
    openModal('modal-start');
  };

  window.quickStop = async function() {
    const data = await api('POST', '/api/bot/stop');
    if (data.success) {
      showToast('Bot stopped', '');
      setTimeout(fetchStatus, 500);
    } else {
      showToast(data.error || 'Failed to stop bot', 'error');
    }
  };

  window.refreshAll = async function() {
    await fetchProfiles();
    await fetchStatus();
    showToast('Refreshed', '');
  };

  // ─── Control Modal ────────────────────────────────────────────────────────
  window.openControlModal = function() {
    if (!botStatus.online) {
      showToast('No bot is running', 'error');
      return;
    }
    const p = botStatus.profile;
    document.getElementById('ctrl-bot-name').textContent = p ? p.name : 'Unknown';
    document.getElementById('ctrl-bot-server').textContent = p ? `${p.host}:${p.port}` : '—';
    openModal('modal-control');
  };

  window.sendAction = async function(action, params = {}) {
    if (!botStatus.online) { showToast('Bot is not running', 'error'); return; }
    const data = await api('POST', '/api/bot/action', { action, params });
    if (!data.success) showToast(data.error || 'Action failed', 'error');
    else if (data.result) {
      if (data.result.following) showToast(`Following: ${data.result.following}`, 'success');
    }
  };

  window.sendChatMsg = async function(msg) {
    if (!botStatus.online) { showToast('Bot is not running', 'error'); return; }
    const data = await api('POST', '/api/bot/chat', { message: msg });
    if (!data.success) showToast(data.error || 'Chat failed', 'error');
  };

  window.sendChatFromInput = async function() {
    const input = document.getElementById('chat-input');
    const msg = input.value.trim();
    if (!msg) return;
    await sendChatMsg(msg);
    input.value = '';
  };

  // ─── Stats Screen ─────────────────────────────────────────────────────────
  window.refreshStats = function() {
    const d = botStatus;
    document.getElementById('stats-uptime').textContent = formatUptime(d.uptime || 0);
    document.getElementById('stats-health').textContent = d.health !== null ? d.health : '—';
    document.getElementById('stats-food').textContent = d.food !== null ? d.food : '—';

    const healthPct = d.health !== null ? (d.health / 20) * 100 : 0;
    const foodPct = d.food !== null ? (d.food / 20) * 100 : 0;
    document.getElementById('bar-health').style.width = `${healthPct}%`;
    document.getElementById('bar-food').style.width = `${foodPct}%`;

    if (d.position) {
      document.getElementById('stats-x').textContent = d.position.x;
      document.getElementById('stats-yz').textContent = `${d.position.y} / ${d.position.z}`;
    } else {
      document.getElementById('stats-x').textContent = '—';
      document.getElementById('stats-yz').textContent = '—';
    }

    const connEl = document.getElementById('stats-connection');
    if (d.online && d.profile) {
      connEl.innerHTML = `
        <span style="color:#3c8527;">● ONLINE</span> &nbsp;
        <strong>${esc(d.profile.name)}</strong> →
        ${esc(d.profile.host)}:${d.profile.port}`;
    } else {
      connEl.innerHTML = '<span style="color:#c83737;">● OFFLINE</span>';
    }
  };

  window.fetchInventory = async function() {
    const el = document.getElementById('inventory-list');
    if (!botStatus.online) { el.textContent = '— start a bot to see inventory —'; return; }
    const data = await api('POST', '/api/bot/action', { action: 'get_inventory' });
    if (data.success && data.result && data.result.items) {
      if (data.result.items.length === 0) {
        el.textContent = 'Inventory is empty';
      } else {
        el.innerHTML = data.result.items.map(i =>
          `<div style="padding:2px 0;border-bottom:1px solid #333;">
            <span style="color:#f0f0f0;">${esc(i.name)}</span>
            <span style="color:#aaa;float:right;">x${i.count}</span>
          </div>`
        ).join('');
      }
    } else {
      el.textContent = data.error || 'Failed to fetch inventory';
    }
  };

  // ─── Logs ─────────────────────────────────────────────────────────────────
  function startLogStream() {
    try {
      logStream = new EventSource(`${API_BASE}/api/logs/stream`);
      logStream.onmessage = e => {
        try {
          const entry = JSON.parse(e.data);
          appendLog(entry.level, entry.message, entry.time);
        } catch (_) {}
      };
      logStream.onerror = () => {
        setTimeout(startLogStream, 5000);
      };
    } catch (_) {}
  }

  function appendLog(level, message, time) {
    const container = document.getElementById('logs-container');
    if (!container) return;
    const t = time ? new Date(time).toLocaleTimeString() : new Date().toLocaleTimeString();
    const el = document.createElement('div');
    el.className = 'log-entry';
    el.innerHTML = `
      <span class="log-time">${t}</span>
      <span class="log-tag ${level}">[${level}]</span>
      <span class="log-msg">${esc(message)}</span>`;
    container.appendChild(el);
    if (autoscroll) container.scrollTop = container.scrollHeight;
  }

  window.clearLogs = function() {
    document.getElementById('logs-container').innerHTML = '';
  };

  window.toggleAutoscroll = function() {
    autoscroll = !autoscroll;
    const btn = document.getElementById('btn-autoscroll');
    btn.style.opacity = autoscroll ? '1' : '0.4';
    showToast(`Autoscroll ${autoscroll ? 'on' : 'off'}`, '');
  };

  // ─── Event Stream ─────────────────────────────────────────────────────────
  function startEventStream() {
    try {
      eventStream = new EventSource(`${API_BASE}/api/events/stream`);
      eventStream.onmessage = e => {
        try {
          const ev = JSON.parse(e.data);
          handleBotEvent(ev);
        } catch (_) {}
      };
      eventStream.onerror = () => {
        setTimeout(startEventStream, 5000);
      };
    } catch (_) {}
  }

  function handleBotEvent(ev) {
    const container = document.getElementById('recent-events');
    const noEv = container.querySelector('.no-events');
    if (noEv) noEv.remove();

    const t = new Date(ev.time).toLocaleTimeString();
    const icon = eventIcon(ev.type);
    const msg = eventMsg(ev.type, ev.data);

    const el = document.createElement('div');
    el.className = 'event-item';
    el.innerHTML = `<span class="event-time">${t}</span><span>${icon} ${msg}</span>`;
    container.insertBefore(el, container.firstChild);

    while (container.children.length > 20) container.removeChild(container.lastChild);

    if (ev.type === 'health' && ev.data) {
      botStatus.health = ev.data.health;
      botStatus.food = ev.data.food;
      document.getElementById('stat-health').textContent = ev.data.health;
      document.getElementById('stat-food').textContent = ev.data.food;
    }

    if (ev.type === 'spawn') { botStatus.online = true; fetchStatus(); }
    if (ev.type === 'disconnect' || ev.type === 'kicked' || ev.type === 'stopped') {
      botStatus.online = false;
      fetchStatus();
    }
  }

  function eventIcon(type) {
    const map = {
      spawn: '✅', chat: '💬', death: '💀', kicked: '🔴',
      disconnect: '🔌', health: '❤️', error: '⚠️', playerJoined: '👋',
      playerLeft: '🚪', reconnecting: '🔄', stopped: '⏹️'
    };
    return map[type] || '📌';
  }

  function eventMsg(type, data) {
    if (!data) return type;
    switch (type) {
      case 'spawn': return `Bot spawned on ${esc(data.host || '')}`;
      case 'chat': return `<${esc(data.username || '')}> ${esc(data.message || '')}`;
      case 'death': return `Bot died`;
      case 'kicked': return `Kicked: ${esc(String(data.reason || ''))}`;
      case 'disconnect': return `Disconnected: ${esc(String(data.reason || ''))}`;
      case 'health': return `Health: ${data.health} ❤️ Food: ${data.food} 🍖`;
      case 'playerJoined': return `${esc(data.username || '')} joined`;
      case 'playerLeft': return `${esc(data.username || '')} left`;
      case 'reconnecting': return `Reconnecting in ${(data.delay || 5000) / 1000}s...`;
      case 'stopped': return 'Bot stopped';
      case 'error': return esc(data.message || 'Unknown error');
      default: return type;
    }
  }

  // ─── Utilities ────────────────────────────────────────────────────────────
  function esc(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatUptime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return [h, m, s].map(v => String(v).padStart(2, '0')).join(':');
  }

})();
