@echo off
REM ─────────────────────────────────────────────────────────────
REM  Flaxon Bot — Quick Start (Windows)
REM  Double-click or run: start.bat
REM ─────────────────────────────────────────────────────────────

echo.
echo   Flaxon Studio Bot
echo   -----------------------------------
echo.

where node >nul 2>&1
IF ERRORLEVEL 1 (
    echo   [ERROR] Node.js not found.
    echo   Install from https://nodejs.org/
    pause
    exit /b 1
)

for /f %%i in ('node -e "process.stdout.write(process.version)"') do set NODE_VER=%%i
echo   Node.js %NODE_VER% found

IF NOT EXIST "%~dp0backend\node_modules" (
    echo   Installing backend dependencies...
    cd /d "%~dp0backend"
    npm install
    echo   Dependencies installed
)

echo   Starting server on http://127.0.0.1:3000
echo   -----------------------------------
echo.

cd /d "%~dp0backend"
node server.js
pause
