const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'profiles.json');

function ensureDb() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, JSON.stringify({ profiles: [] }), 'utf8');
}

function read() {
  ensureDb();
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch {
    return { profiles: [] };
  }
}

function write(data) {
  ensureDb();
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

function getAll() {
  return read().profiles;
}

function getById(id) {
  return read().profiles.find(p => p.id === id) || null;
}

function create(profile) {
  const data = read();
  data.profiles.push(profile);
  write(data);
  return profile;
}

function update(id, fields) {
  const data = read();
  const idx = data.profiles.findIndex(p => p.id === id);
  if (idx === -1) throw new Error('Profile not found');
  data.profiles[idx] = { ...data.profiles[idx], ...fields };
  write(data);
  return data.profiles[idx];
}

function remove(id) {
  const data = read();
  data.profiles = data.profiles.filter(p => p.id !== id);
  write(data);
}

module.exports = { getAll, getById, create, update, remove };
