let mineflayer;
let pathfinderModule;
let movementsModule;

try {
  mineflayer = require('mineflayer');
  const pf = require('mineflayer-pathfinder');
  pathfinderModule = pf.pathfinder;
  movementsModule = pf.Movements;
} catch (e) {
  console.warn('[BotManager] mineflayer or mineflayer-pathfinder not installed yet. Run npm install in backend/.');
}

let activeBot = null;
let activeBotMeta = null;
let botStartTime = null;
let messageLog = [];
let eventLog = [];

const MAX_LOG = 200;
const RECONNECT_DELAY_MS = 5000;
let reconnectTimer = null;
let shouldReconnect = false;

function log(level, msg) {
  const entry = { time: new Date().toISOString(), level, message: msg };
  console.log(`[${level}] ${msg}`);
  if (global.broadcastLog) global.broadcastLog(level, msg);
}

function emitEvent(type, data) {
  const entry = { type, data, time: new Date().toISOString() };
  eventLog.unshift(entry);
  if (eventLog.length > MAX_LOG) eventLog.pop();
  if (global.broadcastEvent) global.broadcastEvent(type, data);
}

function getActiveBot() {
  return activeBotMeta;
}

function getStatus() {
  const online = activeBot !== null && activeBotMeta !== null;
  let uptime = 0;
  if (online && botStartTime) {
    uptime = Math.floor((Date.now() - botStartTime) / 1000);
  }

  let health = null;
  let food = null;
  let position = null;

  if (activeBot) {
    try { health = Math.round(activeBot.health || 0); } catch (_) {}
    try { food = Math.round(activeBot.food || 0); } catch (_) {}
    try {
      const pos = activeBot.entity && activeBot.entity.position;
      if (pos) position = { x: Math.round(pos.x), y: Math.round(pos.y), z: Math.round(pos.z) };
    } catch (_) {}
  }

  return {
    online,
    profile: activeBotMeta,
    uptime,
    health,
    food,
    position,
    recentMessages: messageLog.slice(0, 20),
    recentEvents: eventLog.slice(0, 20)
  };
}

async function startBot(profile) {
  if (!mineflayer) throw new Error('mineflayer is not installed. Run: npm install in the backend directory.');

  if (activeBot) throw new Error('A bot is already running');

  shouldReconnect = true;
  return _createBot(profile);
}

function _createBot(profile) {
  return new Promise((resolve, reject) => {
    log('INFO', `Connecting as "${profile.name}" to ${profile.host}:${profile.port}`);

    let bot;
    try {
      bot = mineflayer.createBot({
        host: profile.host,
        port: profile.port,
        username: profile.name,
        version: false,
        auth: 'offline',
        hideErrors: false,
        checkTimeoutInterval: 30000,
        pingTimeout: 15000
      });
    } catch (err) {
      log('ERROR', `Failed to create bot: ${err.message}`);
      return reject(err);
    }

    let spawned = false;

    bot.once('spawn', () => {
      spawned = true;
      activeBot = bot;
      activeBotMeta = { profileId: profile.id, name: profile.name, host: profile.host, port: profile.port };
      botStartTime = Date.now();

      log('SUCCESS', `Bot "${profile.name}" spawned on ${profile.host}:${profile.port}`);
      emitEvent('spawn', { name: profile.name, host: profile.host });

      if (pathfinderModule && movementsModule) {
        try {
          bot.loadPlugin(pathfinderModule);
          const defaultMove = new movementsModule(bot);
          bot.pathfinder.setMovements(defaultMove);
          log('INFO', 'Pathfinder plugin loaded');
        } catch (e) {
          log('WARN', `Pathfinder load failed: ${e.message}`);
        }
      }

      resolve();
    });

    bot.on('chat', (username, message) => {
      const entry = { username, message, time: new Date().toISOString() };
      messageLog.unshift(entry);
      if (messageLog.length > MAX_LOG) messageLog.pop();
      emitEvent('chat', entry);
      log('INFO', `[CHAT] <${username}> ${message}`);
    });

    bot.on('death', () => {
      log('WARN', `Bot "${profile.name}" died`);
      emitEvent('death', { name: profile.name });
    });

    bot.on('health', () => {
      emitEvent('health', {
        health: Math.round(bot.health || 0),
        food: Math.round(bot.food || 0)
      });
    });

    bot.on('kicked', reason => {
      const msg = typeof reason === 'object' ? JSON.stringify(reason) : String(reason);
      log('WARN', `Bot kicked: ${msg}`);
      emitEvent('kicked', { reason: msg });
      _cleanup();
      if (shouldReconnect) _scheduleReconnect(profile);
    });

    bot.on('end', reason => {
      log('WARN', `Bot disconnected: ${reason || 'unknown'}`);
      emitEvent('disconnect', { reason: reason || 'unknown' });
      _cleanup();
      if (shouldReconnect) _scheduleReconnect(profile);
    });

    bot.on('error', err => {
      log('ERROR', `Bot error: ${err.message}`);
      emitEvent('error', { message: err.message });
      if (!spawned) {
        _cleanup();
        reject(err);
      }
    });

    bot.on('playerJoined', player => {
      if (player.username !== profile.name) {
        emitEvent('playerJoined', { username: player.username });
      }
    });

    bot.on('playerLeft', player => {
      emitEvent('playerLeft', { username: player.username });
    });

    setTimeout(() => {
      if (!spawned) {
        bot.end();
        _cleanup();
        const err = new Error(`Connection timeout to ${profile.host}:${profile.port}`);
        log('ERROR', err.message);
        reject(err);
      }
    }, 20000);
  });
}

function _scheduleReconnect(profile) {
  if (reconnectTimer) return;
  log('INFO', `Reconnecting in ${RECONNECT_DELAY_MS / 1000}s...`);
  emitEvent('reconnecting', { delay: RECONNECT_DELAY_MS });
  reconnectTimer = setTimeout(async () => {
    reconnectTimer = null;
    if (!shouldReconnect) return;
    try {
      await _createBot(profile);
    } catch (err) {
      log('ERROR', `Reconnect failed: ${err.message}`);
      _scheduleReconnect(profile);
    }
  }, RECONNECT_DELAY_MS);
}

function _cleanup() {
  activeBot = null;
  activeBotMeta = null;
  botStartTime = null;
}

async function stopBot() {
  shouldReconnect = false;

  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }

  if (!activeBot) return;

  try {
    activeBot.end();
  } catch (_) {}

  _cleanup();
  log('INFO', 'Bot stopped');
  emitEvent('stopped', {});
}

function sendChat(message) {
  if (!activeBot) return { success: false, error: 'No bot is running' };
  try {
    activeBot.chat(message);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

function executeAction(action, params) {
  if (!activeBot) return { success: false, error: 'No bot is running' };

  try {
    switch (action) {
      case 'move_forward':
        activeBot.setControlState('forward', true);
        setTimeout(() => { try { activeBot.setControlState('forward', false); } catch(_){} }, params.duration || 500);
        return { success: true };

      case 'move_back':
        activeBot.setControlState('back', true);
        setTimeout(() => { try { activeBot.setControlState('back', false); } catch(_){} }, params.duration || 500);
        return { success: true };

      case 'move_left':
        activeBot.setControlState('left', true);
        setTimeout(() => { try { activeBot.setControlState('left', false); } catch(_){} }, params.duration || 500);
        return { success: true };

      case 'move_right':
        activeBot.setControlState('right', true);
        setTimeout(() => { try { activeBot.setControlState('right', false); } catch(_){} }, params.duration || 500);
        return { success: true };

      case 'jump':
        activeBot.setControlState('jump', true);
        setTimeout(() => { try { activeBot.setControlState('jump', false); } catch(_){} }, 200);
        return { success: true };

      case 'sneak':
        activeBot.setControlState('sneak', !activeBot.getControlState('sneak'));
        return { success: true };

      case 'sprint':
        activeBot.setControlState('sprint', !activeBot.getControlState('sprint'));
        return { success: true };

      case 'attack': {
        const entity = activeBot.nearestEntity(e => e.type === 'mob' || (e.type === 'player' && e.username !== activeBot.username));
        if (!entity) return { success: false, error: 'No entity in range' };
        activeBot.attack(entity);
        return { success: true };
      }

      case 'drop_item': {
        const item = activeBot.inventory.items()[0];
        if (!item) return { success: false, error: 'No items in inventory' };
        activeBot.toss(item.type, null, 1);
        return { success: true };
      }

      case 'respawn':
        activeBot.respawn();
        return { success: true };

      case 'look_north':
        activeBot.look(Math.PI, 0, true);
        return { success: true };

      case 'look_south':
        activeBot.look(0, 0, true);
        return { success: true };

      case 'look_east':
        activeBot.look(-Math.PI / 2, 0, true);
        return { success: true };

      case 'look_west':
        activeBot.look(Math.PI / 2, 0, true);
        return { success: true };

      case 'stop_all':
        ['forward','back','left','right','jump','sneak','sprint'].forEach(k => {
          try { activeBot.setControlState(k, false); } catch(_) {}
        });
        if (activeBot.pathfinder) {
          try { activeBot.pathfinder.stop(); } catch(_) {}
        }
        return { success: true };

      case 'follow_nearest_player': {
        if (!activeBot.pathfinder) return { success: false, error: 'Pathfinder not loaded' };
        const { GoalFollow } = require('mineflayer-pathfinder').goals;
        const player = activeBot.nearestEntity(e => e.type === 'player' && e.username !== activeBot.username);
        if (!player) return { success: false, error: 'No player nearby' };
        activeBot.pathfinder.setGoal(new GoalFollow(player, 2), true);
        return { success: true, data: { following: player.username } };
      }

      case 'get_inventory': {
        const items = activeBot.inventory.items().map(i => ({
          name: i.name,
          count: i.count,
          slot: i.slot
        }));
        return { success: true, data: { items } };
      }

      case 'get_position': {
        const pos = activeBot.entity && activeBot.entity.position;
        if (!pos) return { success: false, error: 'Position unavailable' };
        return { success: true, data: { x: Math.round(pos.x), y: Math.round(pos.y), z: Math.round(pos.z) } };
      }

      case 'get_players': {
        const players = Object.keys(activeBot.players || {});
        return { success: true, data: { players } };
      }

      default:
        return { success: false, error: `Unknown action: ${action}` };
    }
  } catch (err) {
    return { success: false, error: err.message };
  }
}

module.exports = { getActiveBot, getStatus, startBot, stopBot, sendChat, executeAction };
