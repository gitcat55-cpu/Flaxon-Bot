const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const botManager = require('./botManager');
const profileStore = require('./profileStore');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(morgan('dev'));

app.use(express.static(path.join(__dirname, '../frontend')));

// ─── SSE Log Stream ──────────────────────────────────────────────────────────
const logClients = new Set();

function broadcastLog(level, message) {
  const entry = { time: new Date().toISOString(), level, message };
  const data = `data: ${JSON.stringify(entry)}\n\n`;
  logClients.forEach(res => {
    try { res.write(data); } catch (_) { logClients.delete(res); }
  });
}

global.broadcastLog = broadcastLog;

app.get('/api/logs/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.flushHeaders();

  logClients.add(res);
  broadcastLog('INFO', 'Log stream connected');

  req.on('close', () => {
    logClients.delete(res);
  });
});

// ─── Profile Routes ───────────────────────────────────────────────────────────
app.get('/api/profiles', (req, res) => {
  try {
    const profiles = profileStore.getAll();
    res.json({ success: true, profiles });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/profiles', (req, res) => {
  try {
    const { name, host, port } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return res.status(400).json({ success: false, error: 'Bot name is required' });
    }
    if (!host || typeof host !== 'string' || host.trim().length === 0) {
      return res.status(400).json({ success: false, error: 'Server host is required' });
    }
    const portNum = parseInt(port, 10);
    if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
      return res.status(400).json({ success: false, error: 'Port must be between 1 and 65535' });
    }

    const profile = profileStore.create({
      id: uuidv4(),
      name: name.trim(),
      host: host.trim(),
      port: portNum,
      createdAt: new Date().toISOString()
    });

    broadcastLog('SUCCESS', `Profile created: ${profile.name}`);
    res.status(201).json({ success: true, profile });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/profiles/:id', (req, res) => {
  try {
    const { id } = req.params;
    const { name, host, port } = req.body;

    if (!name || typeof name !== 'string' || name.trim().length === 0) {
      return res.status(400).json({ success: false, error: 'Bot name is required' });
    }
    if (!host || typeof host !== 'string' || host.trim().length === 0) {
      return res.status(400).json({ success: false, error: 'Server host is required' });
    }
    const portNum = parseInt(port, 10);
    if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
      return res.status(400).json({ success: false, error: 'Port must be between 1 and 65535' });
    }

    const existing = profileStore.getById(id);
    if (!existing) {
      return res.status(404).json({ success: false, error: 'Profile not found' });
    }

    const activeBot = botManager.getActiveBot();
    if (activeBot && activeBot.profileId === id) {
      return res.status(409).json({ success: false, error: 'Cannot edit profile while bot is active. Stop the bot first.' });
    }

    const updated = profileStore.update(id, {
      name: name.trim(),
      host: host.trim(),
      port: portNum,
      updatedAt: new Date().toISOString()
    });

    broadcastLog('INFO', `Profile updated: ${updated.name}`);
    res.json({ success: true, profile: updated });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.delete('/api/profiles/:id', (req, res) => {
  try {
    const { id } = req.params;
    const profile = profileStore.getById(id);
    if (!profile) {
      return res.status(404).json({ success: false, error: 'Profile not found' });
    }

    const activeBot = botManager.getActiveBot();
    if (activeBot && activeBot.profileId === id) {
      return res.status(409).json({ success: false, error: 'Cannot delete active profile. Stop the bot first.' });
    }

    profileStore.remove(id);
    broadcastLog('WARN', `Profile deleted: ${profile.name}`);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Bot Routes ───────────────────────────────────────────────────────────────
app.get('/api/bot/status', (req, res) => {
  const status = botManager.getStatus();
  res.json({ success: true, ...status });
});

app.post('/api/bot/start', async (req, res) => {
  try {
    const { profileId } = req.body;
    if (!profileId) {
      return res.status(400).json({ success: false, error: 'profileId is required' });
    }

    const profile = profileStore.getById(profileId);
    if (!profile) {
      return res.status(404).json({ success: false, error: 'Profile not found' });
    }

    const existing = botManager.getActiveBot();
    if (existing) {
      return res.status(409).json({ success: false, error: 'A bot is already running. Stop it first.' });
    }

    broadcastLog('INFO', `Starting bot "${profile.name}" → ${profile.host}:${profile.port}`);
    await botManager.startBot(profile);
    res.json({ success: true, message: 'Bot is connecting...' });
  } catch (err) {
    broadcastLog('ERROR', `Failed to start bot: ${err.message}`);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/bot/stop', async (req, res) => {
  try {
    const activeBot = botManager.getActiveBot();
    if (!activeBot) {
      return res.status(400).json({ success: false, error: 'No bot is currently running' });
    }
    await botManager.stopBot();
    broadcastLog('WARN', 'Bot stopped by user');
    res.json({ success: true, message: 'Bot stopped' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/bot/chat', (req, res) => {
  try {
    const { message } = req.body;
    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      return res.status(400).json({ success: false, error: 'Message is required' });
    }

    const result = botManager.sendChat(message.trim());
    if (!result.success) {
      return res.status(400).json(result);
    }
    broadcastLog('INFO', `Chat sent: ${message.trim()}`);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/bot/action', (req, res) => {
  try {
    const { action, params } = req.body;
    if (!action) {
      return res.status(400).json({ success: false, error: 'action is required' });
    }

    const result = botManager.executeAction(action, params || {});
    if (!result.success) {
      return res.status(400).json(result);
    }

    broadcastLog('INFO', `Action executed: ${action}`);
    res.json({ success: true, result: result.data });
  } catch (err) {
    broadcastLog('ERROR', `Action error: ${err.message}`);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── SSE Bot Events Stream ─────────────────────────────────────────────────
const eventClients = new Set();

function broadcastEvent(type, data) {
  const payload = `data: ${JSON.stringify({ type, data, time: new Date().toISOString() })}\n\n`;
  eventClients.forEach(res => {
    try { res.write(payload); } catch (_) { eventClients.delete(res); }
  });
}

global.broadcastEvent = broadcastEvent;

app.get('/api/events/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.flushHeaders();

  eventClients.add(res);
  req.on('close', () => eventClients.delete(res));
});

// ─── Catch-all for SPA ────────────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Flaxon Bot Server running on http://0.0.0.0:${PORT}`);
  broadcastLog('SUCCESS', `Server started on port ${PORT}`);
});

process.on('uncaughtException', err => {
  console.error('Uncaught Exception:', err);
  broadcastLog('ERROR', `Uncaught exception: ${err.message}`);
});

process.on('unhandledRejection', reason => {
  console.error('Unhandled Rejection:', reason);
  broadcastLog('ERROR', `Unhandled rejection: ${reason}`);
});
