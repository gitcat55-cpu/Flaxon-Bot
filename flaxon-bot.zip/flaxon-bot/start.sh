#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Flaxon Bot — Quick Start Script
#  Usage: bash start.sh
# ─────────────────────────────────────────────────────────────

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"

echo ""
echo "  🤖  Flaxon Studio Bot"
echo "  ─────────────────────────────────────"
echo ""

# Check Node.js
if ! command -v node &>/dev/null; then
  echo "  ❌  Node.js not found."
  echo "      Install it from https://nodejs.org/ or via Termux: pkg install nodejs"
  exit 1
fi

NODE_VER=$(node -e "process.stdout.write(process.version)")
echo "  ✅  Node.js $NODE_VER"

# Install dependencies if needed
if [ ! -d "$BACKEND_DIR/node_modules" ]; then
  echo "  📦  Installing backend dependencies..."
  cd "$BACKEND_DIR" && npm install
  echo "  ✅  Dependencies installed"
fi

echo "  🚀  Starting server on http://127.0.0.1:3000"
echo "  ─────────────────────────────────────"
echo ""

cd "$BACKEND_DIR"
node server.js
